const baseUrl = "http://localhost:3000";
export const transactionsApi = `${baseUrl}/transactions`;

export const statisticsApi = `${baseUrl}/statistics`;

export const barApi = `${baseUrl}/bar-chart`;

export const pieApi = `${baseUrl}/pie-chart`;
